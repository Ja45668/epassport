package com.wipro.Epassport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpassportApplication {

	public static void main(String[] args) {
		SpringApplication.run(EpassportApplication.class, args);
	}

}
